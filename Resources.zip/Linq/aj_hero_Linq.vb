Partial Public Class aj_hero_LinqDataContext
End Class
